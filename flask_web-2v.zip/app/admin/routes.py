from flask import Blueprint, render_template, redirect
from flask_login import login_required, current_user
from app.models import Usuario

admin_bp = Blueprint('admin', __name__)

@admin_bp.route('/admin')
@login_required
def admin_home():
    if not current_user.is_admin:
        return redirect('/user')
    users = Usuario.query.all()
    return render_template('admin.html', users=users)
