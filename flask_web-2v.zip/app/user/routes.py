from flask import Blueprint, render_template, redirect
from flask_login import login_required, current_user

user_bp = Blueprint('user', __name__)

@user_bp.route('/user')
@login_required
def user_home():
    if current_user.is_admin:
        return redirect('/admin')
    return render_template('user.html', user=current_user)
