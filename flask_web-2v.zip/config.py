class Config:
    SECRET_KEY = 'chave-super-secreta'
    SQLALCHEMY_DATABASE_URI = 'sqlite:///meusite.db'
    SQLALCHEMY_TRACK_MODIFICATIONS = False
