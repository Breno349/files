from dqn_agent import DQNAgent
from replay_buffer import ReplayBuffer
from env_interface import make_env
import torch
import numpy as np

EPISODES = 500
BATCH_SIZE = 32
GAMMA = 0.99
REPLAY_SIZE = 10_000
TARGET_UPDATE = 10
EPSILON_DECAY = 0.995
MIN_EPSILON = 0.05
N_FRAMES = 4

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
env = make_env()
agent = DQNAgent(num_actions=env.num_actions, device=device, frame_stack=N_FRAMES)
buffer = ReplayBuffer(REPLAY_SIZE)

epsilon = 1.0

for ep in range(EPISODES):
    obs = env.reset()
    agent.reset_frames(obs)
    state = agent.get_state()
    total_reward = 0

    while True:
        action = agent.act(state, epsilon)
        next_obs, reward, done = env.step(action)
        agent.append_frame(next_obs)
        next_state = agent.get_state()

        buffer.push(state, action, reward, next_state, done)
        state = next_state
        total_reward += reward

        if len(buffer) >= BATCH_SIZE:
            batch = buffer.sample(BATCH_SIZE)
            agent.train_step(batch, GAMMA)

        if done:
            break

    epsilon = max(MIN_EPSILON, epsilon * EPSILON_DECAY)

    if ep % TARGET_UPDATE == 0:
        agent.update_target_network()

    print(f"[Ep {ep}] Recompensa: {total_reward} | Epsilon: {epsilon:.2f}")

agent.save("dqn_model.pth")