from dqn_agent import DQNAgent
from env_interface import make_env
import torch

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
env = make_env()
agent = DQNAgent(num_actions=env.num_actions, device=device)
agent.load("dqn_model.pth")

obs = env.reset()
agent.reset_frames(obs)
state = agent.get_state()
total_reward = 0

while True:
    action = agent.act(state, epsilon=0.0)
    next_obs, reward, done = env.step(action)
    agent.append_frame(next_obs)
    state = agent.get_state()
    total_reward += reward
    env.render()
    if done:
        break

print(f"Recompensa total: {total_reward}")