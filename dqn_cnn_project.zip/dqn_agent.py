import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
import random
from collections import deque

class CNN_DQN(nn.Module):
    def __init__(self, in_channels, num_actions):
        super().__init__()
        self.conv = nn.Sequential(
            nn.Conv2d(in_channels, 32, kernel_size=3, padding=1),
            nn.ReLU(),
            nn.Conv2d(32, 64, kernel_size=3, padding=1),
            nn.ReLU()
        )
        self.fc = nn.Sequential(
            nn.Flatten(),
            nn.Linear(64 * 16 * 16, 256),
            nn.ReLU(),
            nn.Linear(256, num_actions)
        )

    def forward(self, x):
        return self.fc(self.conv(x))

class DQNAgent:
    def __init__(self, num_actions, device, frame_stack=4):
        self.device = device
        self.num_actions = num_actions
        self.frame_stack = frame_stack
        self.frame_buffer = deque(maxlen=frame_stack)

        self.model = CNN_DQN(frame_stack, num_actions).to(device)
        self.target_model = CNN_DQN(frame_stack, num_actions).to(device)
        self.target_model.load_state_dict(self.model.state_dict())
        self.optimizer = torch.optim.Adam(self.model.parameters(), lr=1e-4)
        self.criterion = nn.MSELoss()

    def reset_frames(self, initial_obs):
        self.frame_buffer.clear()
        for _ in range(self.frame_stack):
            self.frame_buffer.append(initial_obs)

    def append_frame(self, frame):
        self.frame_buffer.append(frame)

    def get_state(self):
        return np.stack(self.frame_buffer, axis=0)

    def act(self, state, epsilon=0.0):
        if random.random() < epsilon:
            return random.randint(0, self.num_actions - 1)
        state_tensor = torch.tensor(state, dtype=torch.float32).unsqueeze(0).to(self.device)
        with torch.no_grad():
            q_values = self.model(state_tensor)
        return q_values.argmax().item()

    def train_step(self, batch, gamma):
        states, actions, rewards, next_states, dones = batch

        states = torch.tensor(states, dtype=torch.float32).to(self.device)
        next_states = torch.tensor(next_states, dtype=torch.float32).to(self.device)
        actions = torch.tensor(actions).to(self.device)
        rewards = torch.tensor(rewards).to(self.device)
        dones = torch.tensor(dones, dtype=torch.float32).to(self.device)

        q_values = self.model(states)
        current_q = q_values.gather(1, actions.unsqueeze(1)).squeeze(1)

        with torch.no_grad():
            max_next_q = self.target_model(next_states).max(1)[0]
            expected_q = rewards + (1 - dones) * gamma * max_next_q

        loss = self.criterion(current_q, expected_q)
        self.optimizer.zero_grad()
        loss.backward()
        self.optimizer.step()

    def update_target_network(self):
        self.target_model.load_state_dict(self.model.state_dict())

    def save(self, path):
        torch.save(self.model.state_dict(), path)

    def load(self, path):
        self.model.load_state_dict(torch.load(path, map_location=self.device))
        self.update_target_network()