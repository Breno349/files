import numpy as np

class DummyEnv:
    def __init__(self):
        self.size = 16
        self.num_actions = 4

    def reset(self):
        self.agent = [0, 0]
        self.goal = [8, 8]
        return self._get_obs()

    def _get_obs(self):
        grid = np.zeros((self.size, self.size), dtype=np.float32)
        grid[self.goal[0], self.goal[1]] = 0.5
        grid[self.agent[0], self.agent[1]] = 1.0
        return grid

    def step(self, action):
        x, y = self.agent
        if action == 0: x = max(0, x - 1)
        elif action == 1: x = min(self.size - 1, x + 1)
        elif action == 2: y = max(0, y - 1)
        elif action == 3: y = min(self.size - 1, y + 1)
        self.agent = [x, y]
        done = self.agent == self.goal
        reward = 10 if done else -0.1
        return self._get_obs(), reward, done

    def render(self):
        print("Agent:", self.agent)

def make_env():
    return DummyEnv()