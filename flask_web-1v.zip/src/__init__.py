print("\n-\t\033[1;32mServidor iniciado..\033[0m\n");
